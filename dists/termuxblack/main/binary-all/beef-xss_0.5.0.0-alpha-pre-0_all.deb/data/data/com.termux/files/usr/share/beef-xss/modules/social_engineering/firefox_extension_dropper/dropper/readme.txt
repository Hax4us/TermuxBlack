Place in this directory the binary you want to drop and execute through the Firefox extension.
Make sure to have just ONE file in this directory (other than this readme.txt).