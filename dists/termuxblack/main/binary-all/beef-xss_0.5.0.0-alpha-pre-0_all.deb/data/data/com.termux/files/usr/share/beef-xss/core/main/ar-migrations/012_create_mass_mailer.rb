class CreateMassMailer < ActiveRecord::Migration[6.0]

	def change

		create_table :mass_mailers do |t|
            #todo fields
		end

	end

end
