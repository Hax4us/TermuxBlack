heretic-clippy is copyright (c) 2013 sprky0
Homepage: https://github.com/sprky0/heretic-clippy
