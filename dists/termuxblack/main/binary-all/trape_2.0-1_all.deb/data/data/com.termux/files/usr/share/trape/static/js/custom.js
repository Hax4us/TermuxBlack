$(document).ready(function($) {
    /**
     * DO NOT delete this file completely.
     * Your code goes here
     */
})