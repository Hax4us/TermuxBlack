# frozen_string_literal: true
class Gem::Package::Source # :nodoc:
end
