module Reline
  VERSION = '0.1.5'
end
